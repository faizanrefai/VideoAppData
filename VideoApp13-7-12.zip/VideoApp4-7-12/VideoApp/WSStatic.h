//
//  WSStatic.h
//  VideoApp
//
//  Created by Ronak Arora on 13/07/12.
//  Copyright (c) 2012 iverve. All rights reserved.
//


//Play Video in detail

//#define videoPlay  @"http://www.itechcoders.com/dev/videoApp/userVideo.php"



//#define allVideolist  @"http://www.itechcoders.com/dev/videoApp/user_action.php"






// Client Server




#define videoPlay  @"http://www.findyourzone.tv/webservice/userVideo.php"



#define allVideolist  @"http://www.findyourzone.tv/webservice/user_action.php"

